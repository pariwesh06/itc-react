// timer
setTimeout(function(){ //only once
    console.log('1');
} , 2000);

const cancel = setInterval(function(){ //runs every 2 seconds
    console.log('2');
} , 2000);

// function loop(){
//     for(;;);
// }
// loop();