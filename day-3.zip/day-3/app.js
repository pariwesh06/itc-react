// alert('hello');
function add() {
    let = 90;
    console.log(arguments);
    let sum = 0;
    for (let index = 0; index < arguments.length; index++) {
        sum = sum + arguments[index];
    }
    // console.log(index);
    return sum;
}

const result = add(1, 3, 4, -1, 40); //don't var 
console.log(result);
//number, boolean,Date
const a = 1;
// a='ITC';

class User { //ES6
    name = 'Pariwesh';
    age = 30;
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }
    work() {
        console.log(this.name + ' is working');
    }
}

//create an array of 10 user obejcts.
function createUsers(){
    const users = [];
    for (let index = 0; index < 10; index++) {
        const u1 = new User('Ram', index*10);
        users.push(u1);
    }
    return users;
}

const users = createUsers();
users.sort(function( u1, u2 ){
    return u2.age - u1.age;
})
console.log(users);

function saveInStorage(){
    localStorage.setItem('token', 'sdoigheriogh2345uj43tbj3igj@');
    sessionStorage.setItem('token', 'sdoigheriogh2345uj43tbj3igj@');

}

saveInStorage();