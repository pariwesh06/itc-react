function start(){
  const userInput=  document.getElementById('userInput');
  if(!userInput.value){
    alert('please give a number');
    return;
  }
  setInterval(function(){
      console.log(userInput.value);
  }, 1000 * userInput.value);
}